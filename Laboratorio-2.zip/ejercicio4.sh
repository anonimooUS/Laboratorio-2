#!/bin/bash

# Mostramos los procesos de una manera ordenada. Hemos impreso unicamente los que salen en el ejemplo del enunciado, si quisiesemos imprimir todos los procesos, pondríamos unicamente ps aux
mostrar_procesos() {
    clear
    echo "==== Monitor de Recursos Interactivo ===="
    printf "%-8s %-8s %-8s %-8s %-s\n" "PID" "USER" "%CPU" "%MEM" "COMMAND"
    ps aux | awk 'NR > 1 {printf "%-8s %-8s %-8s %-8s %-s\n", $2, $1, $3, $4, $11}'
}

# Mostramos el menu para que el usuario elija un proceso sobre el que quiere realizar acciones
mostrar_menu() {
    echo "Seleccione el PID del proceso para realizar acciones (o presione Enter para salir):"
}

# Una vez que el usuario ha elegido un proceso, mostramos un submenu para que elija la acción que quiere ejecutar sobre el proceso
mostrar_acciones() {
    echo "Acciones disponibles: (1) Detener proceso / (2) Cambiar prioridad:"
}

mostrar_procesos

while true; do
    mostrar_menu
    read -p "PID: " pid

    if [ -z "$pid" ]; then
        echo "Saliendo del script."
        exit 0
    fi

    mostrar_acciones
    read -p "Acción (1 o 2): " accion

    case $accion in
        1)
            kill "$pid"
            echo "Proceso $pid detenido."
            ;;
        2)
            read -p "Ingrese la nueva prioridad (número): " prioridad
            old_prioridad=$(ps -p $pid -o pri=)
            renice "$prioridad" "$pid"
            echo "$pid (process ID) old priority $old_prioridad, new priority $prioridad"
            echo "Prioridad del proceso $pid cambiada a $prioridad."
            ;;
        *)
            echo "Opción no válida. Inténtelo de nuevo."
            ;;
    esac
done
#!/bin/bash

# Comprobamos si se ha pasado el número de archivos requeridos, en caso contrario lo decimos por pantalla
if [ $# -ne 1 ]; then  
  echo "Se requiere el siguiente formato: ./ejercicio1.sh <archivo_log>"
  exit 1
fi

# Asignamos el archivo a la variable "archivo"
archivo="$1"

# Comprobamos si el archivo existe, en caso contrario lo decimos por pantalla
if [ ! -f "$archivo" ]; then
  echo "El archivo de registro 'archivo.txt' no existe."
  exit 1
fi

# Contamos las lineas con error y las lineas con advertencia (sin distinguir entre mayúsculas y minúsculas)
errores=$(grep -ci "error" "$archivo")
advertencias=$(grep -ci "warning" "$archivo")

# En caso de querer hacer distinción entre mayúsculas y minúsculas, se podría hacer así:
# errores=$(grep -c "error" "$archivo")
# advertencias=$(grep -c "warning" "$archivo")


# Imprimimos los resultados
echo "Cantidad de líneas con errores: $errores"
echo "Cantidad de líneas con advertencias: $advertencias"

exit 0
#!/bin/bash

# Comprobamos si se ha pasado el número de directorios requeridos, en caso contrario lo decimos por pantalla
if [ $# -ne 1 ]; then
  echo "Se requiere el siguiente formato: ./ejercicio2.sh <directorio>"
  exit 1
fi

# Asignamos el directorio a la variable "archivo"
directorio="$1"

# Comprobamos si el directorio existe, en caso contrario lo decimos por pantalla
if [ ! -d "$directorio" ]; then
  echo "El directorio '$directorio' no existe."
  exit 1
fi

# Contamos el número de archivos y directorios en el directorio
archivos=$(find "$directorio" -type f | wc -l)
directorios=$(find "$directorio" -mindepth 1 -type d | wc -l)

# Imprimimos los resultados
echo "Cantidad total de archivos: $archivos"
echo "Cantidad total de directorios: $directorios"

exit 0
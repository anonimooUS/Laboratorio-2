#!/bin/bash

# Comprobamos si se ha pasado el número de archivos requeridos, en caso contrario lo decimos por pantalla
if [ $# -ne 3 ]; then
  echo "Se requiere el siguiente formato: ./ejercicio3.sh <directorio> <patron>
<reemplazo>"
  exit 1
fi

# Asignamos cada archivo a una variable 
directorio="$1"
patron="$2"
reemplazo="$3"

# Comprobamos si el directorio existe, en caso contrario lo decimos por pantalla
if [ ! -d "$directorio" ]; then
    echo "El directorio $directorio no existe"
    exit 1
fi

# Buscamos y sustituimos el patron por el reemplazo en todos los archivos del directorio que contengan el patron. Para ello usamos el comando 'sed'
find "$directorio" -type f -exec sed -i "s/$patron/$reemplazo/g" {} +

# Imprimimos el mensaje de confirmación
echo "Reemplazo completado en todos los archivos del directorio $directorio y sus subdirectorios"

exit 0